﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INFT3050_Assignment1.Models
{
    public class ShoppingCart
    {
        public int cartID { get; set; }
        public int userID { get; set; }
    }
}